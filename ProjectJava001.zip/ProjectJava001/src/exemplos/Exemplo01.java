package exemplos;

public class Exemplo01 {
	public static void main(String[]args) {
		System.out.println("equipe04");//imprimir uma mensagem e pular uma linha no sistema
}
}
