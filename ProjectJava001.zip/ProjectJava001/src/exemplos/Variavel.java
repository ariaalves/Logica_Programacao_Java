package exemplos;

public class Variavel {
	public static void main(String[]args) {
		int numero1=10;
		int numero2=20;
		
		System.out.println(numero1-numero2);
	}
}
