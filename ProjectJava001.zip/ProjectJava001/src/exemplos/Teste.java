package exemplos;
import java.util.Scanner;

public class Teste {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Digite o primeiro valor: ");
	        double valor1 = scanner.nextDouble();

	        System.out.print("Digite o segundo valor: ");
	        double valor2 = scanner.nextDouble();

	        System.out.print("Digite o terceiro valor: ");
	        double valor3 = scanner.nextDouble();

	        double menor, meio, maior;

	        if (valor1 < valor2 && valor1 < valor3) {
	            menor = valor1;
	            if (valor2 < valor3) {
	                meio = valor2;
	                maior = valor3;
	            } else {
	                meio = valor3;
	                maior = valor2;
	            }
	        } else if (valor2 < valor1 && valor2 < valor3) {
	            menor = valor2;
	            if (valor1 < valor3) {
	                meio = valor1;
	                maior = valor3;
	            } else {
	                meio = valor3;
	                maior = valor1;
	            }
	        } else {
	            menor = valor3;
	            if (valor1 < valor2) {
	                meio = valor1;
	                maior = valor2;
	            } else {
	                meio = valor2;
	                maior = valor1;
	            }
	        }

	        System.out.println("Os valores em ordem crescente s�o: " + menor + ", " + meio + ", " + maior);

	        scanner.close();
	    }}
	
