package faccat;
import java.util.Scanner;

public class Exercicio29IfElseSomaMaiores {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o primeiro n�mero: ");
		int numero01=sc.nextInt();
		System.out.println("Digite o segundo n�mero: ");
		int numero02=sc.nextInt();
		System.out.println("Digite o terceiro n�mero: ");
		int numero03=sc.nextInt();
		
		int soma01=numero01+numero02;
		int soma02=numero02+numero03;
	    int soma03=numero01+numero03;
	    
		    if(numero01==numero02 || numero02==numero03 || numero01==numero03){
	            System.out.println("Os n�meros n�o podem ser iguais. Tente novamente");
	        }
	
	        else if(numero01>numero03 && numero02>numero03){
	            System.out.println("A soma dos dois maiores n�meros �: " + soma01);
	        }
	
	        else if(numero02>numero01 && numero03>numero01){
	            System.out.println("A soma dos dois maiores n�meros �: " + soma02);
	        }
	
	        else{
	            System.out.println("A soma dos dois maiores n�meros �: " + soma03);
	        }
		    
		   sc.close();

	}
}
