package faccat;
import java.util.Scanner;

public class Exercicio37IfElsePrecoTotalFrutas {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite a quantidade de morangos em Kg: ");
        float qtdMorangos = sc.nextFloat();
        
        System.out.print("Digite a quantidade de ma��s em Kg: ");
        float qtdMacas = sc.nextFloat();
        
        float precoMorangos = 0;
	        if (qtdMorangos <= 5) {
	            precoMorangos = qtdMorangos * 2.5f;
	        } 
	        
	        else {
	            precoMorangos = qtdMorangos * 2.2f;
	        }
        
        float precoMacas = 0;
	        if (qtdMacas <= 5) {
	            precoMacas = qtdMacas * 1.8f;
	        } 
	        
	        else {
	            precoMacas = qtdMacas * 1.5f;
	        }
        
        float precoTotal = precoMorangos + precoMacas;
        
	        if (precoTotal > 25 || (qtdMorangos + qtdMacas) > 8) {
	            precoTotal *= 0.9f;
	        }
        
        System.out.printf("O pre�o total a ser pago �: R$ %.2f\n", precoTotal);
        
        sc.close();
	}
}
