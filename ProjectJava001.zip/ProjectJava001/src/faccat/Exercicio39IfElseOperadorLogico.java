package faccat;

public class Exercicio39IfElseOperadorLogico {
	public static void main(String[]args) {
		boolean A = true;
        boolean B = true;
        boolean C = false;
        
        boolean a = (A && B) || (A ^ B);
        System.out.println("Resultado de (A e B) ou (A ou B): " + a);

        boolean b = (A || B) && (A && C);
        System.out.println("Resultado de (A ou B) e (A e C): " + b);

        boolean c = A || (C && B) ^ (A && !B);
        System.out.println("Resultado de (A ou C) e (B ou A) e (n�o B): " + c);
	}
}
