package faccat;
import java.util.Scanner;

public class Exercicio26IfElseControleEstoque {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite a quantidade atual do estoque: ");
		int quantAtual=sc.nextInt();
		System.out.println("Digite a quantidade m�xima do estoque: ");
		int quantMax=sc.nextInt();
		System.out.println("Digite a quantidade m�nima do estoque: ");
		int quantMin=sc.nextInt();
		float quantMedia=(quantMax+quantMin)/2;
		
			if(quantAtual>=quantMedia) {
				System.out.println("N�O EFETUAR COMPRA");
			}
			
			else {
				System.out.println("EFETUAR COMPRA");
			}
			
			sc.close();
	}
}
