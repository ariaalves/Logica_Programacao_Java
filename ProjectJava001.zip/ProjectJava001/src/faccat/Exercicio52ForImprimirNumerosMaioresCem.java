package faccat;

public class Exercicio52ForImprimirNumerosMaioresCem {
	public static void main(String[]args) {
		for (int i = 101; i <= 110; i++) {
			System.out.println(i);
		}
	}
}
