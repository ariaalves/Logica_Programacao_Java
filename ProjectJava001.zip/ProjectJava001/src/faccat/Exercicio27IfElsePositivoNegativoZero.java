package faccat;
import java.util.Scanner;

public class Exercicio27IfElsePositivoNegativoZero {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite um n�mero: ");
		int numero=sc.nextInt();
		
			if(numero>0) {
				System.out.println("� POSITIVO!");
			}
			
			else if(numero==0) {
				System.out.println("� ZERO!");
			}
			
			else {
				System.out.println("� NEGATIVO!");
			}
			
		sc.close();
	}
}
