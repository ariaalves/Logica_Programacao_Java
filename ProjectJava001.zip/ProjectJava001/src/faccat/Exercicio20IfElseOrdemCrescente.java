package faccat;
import java.util.Scanner;
public class Exercicio20IfElseOrdemCrescente {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o primeiro n�mero: ");
		int numero01=sc.nextInt();
		System.out.println("Digite o segundo n�mero: ");
		int numero02=sc.nextInt();
		if(numero01==numero02) {
			System.out.println("Os n�meros s�o iguais, precisamos que sejam diferentes para comparar qual � o maior. Por favor, tente novamente!");
		}
		else if(numero01>numero02) {
			System.out.println(numero02+","+numero01);
		}
		
		else {
			System.out.println(numero01+","+numero02);
		}
		sc.close();
	}
}
