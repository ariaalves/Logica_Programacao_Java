package faccat;

import java.util.Scanner;

public class Exercicio15IfElsePositivoNegativo {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite um n�mero: ");
		int numero=sc.nextInt();
		
			if(numero>=0) {
				System.out.println("� POSITIVO!");
			}
			
			else {
				System.out.println("� NEGATIVO!");
			}
			
		sc.close();
		}
}
