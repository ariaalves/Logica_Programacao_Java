package faccat;
import java.util.Scanner;

public class Exercicio48WhileCalculoMedia {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		char resposta = 'S';

        while (resposta == 'S') {
            System.out.print("Digite a nota da primeira avalia��o: ");
            double nota1 = sc.nextDouble();

	            while (nota1 < 0 || nota1 > 10) {
	                System.out.print("Digite uma nota v�lida (0 a 10) para a primeira avalia��o: ");
	                nota1 = sc.nextDouble();
	            }

            System.out.print("Digite a nota da segunda avalia��o: ");
            double nota2 = sc.nextDouble();

	            while (nota2 < 0 || nota2 > 10) {
	                System.out.print("Digite uma nota v�lida (0 a 10) para a segunda avalia��o: ");
	                nota2 = sc.nextDouble();
	            }

            double media = (nota1 + nota2) / 2;
            System.out.println("A m�dia do aluno �: " + String.format("%.2f", media));

            System.out.print("NOVO C�LCULO (S/N)?");
            resposta = sc.next().charAt(0);
            resposta = Character.toUpperCase(resposta);
        }
        
       sc.close();
	}
}
