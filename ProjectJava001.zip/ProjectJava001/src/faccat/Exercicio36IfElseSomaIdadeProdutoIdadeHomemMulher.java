package faccat;
import java.util.Scanner;

public class Exercicio36IfElseSomaIdadeProdutoIdadeHomemMulher {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
	        
	        System.out.println("Digite a idade do primeiro homem: ");
	        int idadeHomem1 = sc.nextInt();
	        
	        System.out.println("Digite a idade do segundo homem: ");
	        int idadeHomem2 = sc.nextInt();
	        
	        int idadeMaisVelho = 0;
	        int idadeMaisNovo = 0;

	        System.out.println("Digite a idade da primeira mulher: ");
	        int idadeMulher1 = sc.nextInt();
	        
	        System.out.println("Digite a idade da segunda mulher: ");
	        int idadeMulher2 = sc.nextInt();
	        
		        if (idadeHomem1 > idadeHomem2) {
		            idadeMaisVelho = idadeHomem1;
		        } 
		        
		        else {
		            idadeMaisVelho = idadeHomem2;
		        }
	
		        if (idadeMulher1 < idadeMulher2) {
		            idadeMaisNovo = idadeMulher1;
		        } 
		        
		        else {
		            idadeMaisNovo = idadeMulher2;
		        }

	        int somaIdades = idadeMaisVelho + idadeMaisNovo;
	        System.out.println("A soma das idades do homem mais velho com a mulher mais nova �: " + somaIdades);

		        if (idadeHomem1 < idadeHomem2) {
		            idadeMaisNovo = idadeHomem1;
		        } 
		        
		        else {
		            idadeMaisNovo = idadeHomem2;
		        }
	
		        if (idadeMulher1 > idadeMulher2) {
		            idadeMaisVelho = idadeMulher1;
		        } 
		        
		        else {
		            idadeMaisVelho = idadeMulher2;
		        }

	        int produtoIdades = idadeMaisNovo * idadeMaisVelho;
	        System.out.println("O produto das idades do homem mais novo com a mulher mais velha �: " + produtoIdades);
	        
	        sc.close();
	}
	
}

