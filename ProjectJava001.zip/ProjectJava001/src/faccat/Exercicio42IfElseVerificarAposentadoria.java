package faccat;
import java.util.Scanner;
import java.util.Calendar;

public class Exercicio42IfElseVerificarAposentadoria {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Informe o c�digo do empregado: ");
        String codigo = sc.nextLine();

        System.out.print("Informe o ano de nascimento do empregado: ");
        int anoNascimento = sc.nextInt();

        System.out.print("Informe o ano de ingresso do empregado na empresa: ");
        int anoIngresso = sc.nextInt();

        int anoAtual = Calendar.getInstance().get(Calendar.YEAR);
        int idade = anoAtual - anoNascimento;
        int tempoTrabalho = anoAtual - anoIngresso;

        if (idade >= 65 || tempoTrabalho >= 30 || (idade >= 60 && tempoTrabalho >= 25)) {
            System.out.println("C�digo: " + codigo);
            System.out.println("Idade: " + idade + " anos");
            System.out.println("Tempo de trabalho: " + tempoTrabalho + " anos");
            System.out.println("Requerer aposentadoria");
        } 
        
        else {
            System.out.println("C�digo: " + codigo);
            System.out.println("Idade: " + idade + " anos");
            System.out.println("Tempo de trabalho: " + tempoTrabalho + " anos");
            System.out.println("N�o requerer");
        }
        
       sc.close();
	}
}
