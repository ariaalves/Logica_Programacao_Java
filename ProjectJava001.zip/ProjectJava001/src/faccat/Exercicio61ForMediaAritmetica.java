package faccat;
import java.util.Scanner;

public class Exercicio61ForMediaAritmetica {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		int soma = 0;

        for (int i = 1; i <= 10; i++) {
            System.out.print("Digite o " + i + "� valor: ");
            int valor = sc.nextInt();
            soma += valor;
        }

        double media = (double) soma / 10;

        System.out.println("A m�dia aritm�tica dos valores lidos � " + media + ".");
        
     sc.close();
    }
}

