package faccat;
import java.util.Scanner;

public class Exercicio30IfElseOrdemCrescente{
	public static void main(String[]args) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Digite o primeiro n�mero: ");
		int numero01=sc.nextInt();
		System.out.println("Digite o segundo n�mero: ");
		int numero02=sc.nextInt();
		System.out.println("Digite o terceiro n�mero: ");
		int numero03=sc.nextInt();
		
			if(numero01==numero02 || numero02==numero03 || numero01==numero03) {
				System.out.println("Os n�meros n�o podem ser iguais! Por favor, tente novamente.");
			}
		
			else if(numero01>numero02 && numero02>numero03) {
				System.out.println(numero03+","+numero02+","+numero01);
			}
			
			else if(numero01>numero03 && numero03>numero02) {
				System.out.println(numero02+","+numero03+","+numero01);
			}
			
			else if(numero02>numero01 && numero01>numero03) {
				System.out.println(numero03+","+numero01+","+numero02);
			}
			
			else if(numero02>numero03 && numero03>numero01) {
				System.out.println(numero01+","+numero03+","+numero02);
			}
			else if(numero03>numero02 && numero02>numero01) {
				System.out.println(numero01+","+numero02+","+numero03);
			}
			
			else{
				System.out.println(numero02+","+numero01+","+numero03);
			}
			
		sc.close();
	}
}
