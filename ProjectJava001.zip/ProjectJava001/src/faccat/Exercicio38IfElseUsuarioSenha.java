package faccat;
import java.util.Scanner;

public class Exercicio38IfElseUsuarioSenha {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("DIGITE O C�DIGO DE USU�RIO: ");
		String codigo=sc.next();
		if (!codigo.equals("1234")) {
            System.out.println("Usu�rio inv�lido!");
        } 
		
		else {
            System.out.print("Digite a senha: ");
            String senha = sc.next();
            
            if (!senha.equals("9999")) {
                System.out.println("Senha incorreta!");
            } 
            
            else {
                System.out.println("Acesso permitido!");
            }
            
          sc.close();
        }
	}
}
