package faccat;
import java.util.Scanner;

public class Exercicio53WhileForImprimirAteNumero {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		int numero = 0;

	        while (numero <= 0) {
	            System.out.print("Digite um valor maior que zero para N: ");
	            numero = sc.nextInt();
	        }
	
	        for (int i = 1; i <= numero; i++) {
	            System.out.println(i);
	        }
	        
	    sc.close();
	}
}
