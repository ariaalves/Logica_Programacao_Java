package faccat;
import java.util.Scanner;

public class Exercicio59ForContarNegativos {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		int countNegativos = 0;

	        for (int i = 1; i <= 10; i++) {
	            System.out.print("Insira um valor: ");
	            int valor = sc.nextInt();
	
		            if (valor < 0) {
		                countNegativos++;
		            }
	        }

        System.out.println("Foram lidos " + countNegativos + " valores negativos.");
        
      sc.close();
	}
}
