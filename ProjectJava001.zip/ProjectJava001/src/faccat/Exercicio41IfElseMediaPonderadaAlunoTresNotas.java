package faccat;
import java.util.Scanner;

public class Exercicio41IfElseMediaPonderadaAlunoTresNotas {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o nome do aluno: ");
		String nome=sc.nextLine();
		
		System.out.print("Digite a primeira nota: ");
        double nota1 = sc.nextDouble();
        
        System.out.print("Digite a segunda nota: ");
        double nota2 = sc.nextDouble();
        
        System.out.print("Digite a terceira nota: ");
        double nota3 = sc.nextDouble();
        
        System.out.print("Digite a m�dia dos exerc�cios: ");
        double mediaExercicios = sc.nextDouble();
        
        double mediaAproveitamento = (nota1 + nota2 * 2 + nota3 * 3 + mediaExercicios) / 7;
        
        String conceito;
	        if (mediaAproveitamento >= 9.0) {
	            conceito = "A";
	        } 
	        
	        else if (mediaAproveitamento >= 7.5 && mediaAproveitamento < 9.0) {
	            conceito = "B";
	        } 
	        
	        else if (mediaAproveitamento >= 6.0 && mediaAproveitamento < 7.5) {
	            conceito = "C";
	        } 
	        
	        else {
	            conceito = "D";
	        }
	        
        System.out.println(nome+" teve uma m�dia de aproveitamento de: " + String.format("%.1f", mediaAproveitamento));
        System.out.println("Conceito: " + conceito);
        
        sc.close();
	}
}
