package faccat;
import java.util.Scanner;
public class Exercicio07IdadeEmDias {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite a sua idade expressa em anos: ");
		int anos=sc.nextInt();
		System.out.println("Digite a sua idade expressa em meses: ");
		int meses=sc.nextInt();
		System.out.println("Digite a sua idade expressa em dias: ");
		int dias=sc.nextInt();
		int anosDias=anos*365;
		int mesesDias=meses*30;
		int idadeDias=anosDias+mesesDias+dias;
		System.out.println("A sua idade expressa apenas em dias � de: "+idadeDias+" dias!");
		sc.close();
	}
}
