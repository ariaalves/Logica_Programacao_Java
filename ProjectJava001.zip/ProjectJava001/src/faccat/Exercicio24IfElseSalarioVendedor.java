package faccat;
import java.util.Scanner;

public class Exercicio24IfElseSalarioVendedor {
	public static void main (String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o sal�rio fixo mensal do vendedor: ");
		float salarioFixo=sc.nextFloat();
		System.out.println("Digite o valor total das vendas que esse vendedor realizou: ");
		float totalVenda=sc.nextFloat();
		float comissao01=(totalVenda*3)/100;
		float comissao02=(1500*3/100)+((totalVenda-1500)*5/100);
		float salarioFinal01=salarioFixo+comissao01;
		float salarioFinal02=salarioFixo+comissao02;
			
			if(totalVenda<=1500) {
				System.out.println("O sal�rio final do vendedor �: R$ "+salarioFinal01);
			}
			
			else {
				System.out.println("O sal�rio final do vendedor �: R$ "+salarioFinal02);
			}
			
			sc.close();
		}
			
	}

