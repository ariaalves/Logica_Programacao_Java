package faccat;
import java.util.Scanner;

public class Exercicio60ForContarValoresIntervalo {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		int valoresDentroIntervalo = 0;
        int valoresForaIntervalo = 0;

	        for (int i = 0; i < 10; i++) {
	            System.out.print("Digite um valor: ");
	            int valor = sc.nextInt();
		
		            if (valor >= 10 && valor <= 20) {
		                valoresDentroIntervalo++;
		            } 
		            
		            else {
		                valoresForaIntervalo++;
		            }
		        }

        System.out.println("Valores dentro do intervalo: " + valoresDentroIntervalo);
        System.out.println("Valores fora do intervalo: " + valoresForaIntervalo);
        
      sc.close();
	}
}
