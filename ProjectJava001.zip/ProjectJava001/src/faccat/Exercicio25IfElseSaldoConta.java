package faccat;
import java.util.Scanner;

public class Exercicio25IfElseSaldoConta {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o n�mero da sua conta: ");
		int numeroConta=sc.nextInt();
		System.out.println("Digite o saldo da sua conta: ");
		float saldo=sc.nextFloat();
		System.out.println("Digite o valor que foi retirado dela: ");
		float debito=sc.nextFloat();
		System.out.println("Digite o valor que vai ser depositado: ");
		float credito=sc.nextFloat();
		float saldoAtual=(saldo-debito)+credito;
		
			if(saldoAtual>=0) {
				System.out.println(numeroConta+" o seu saldo � de: R$ "+saldoAtual+" e est� positivo!");
			}
			
			else {
				System.out.println(numeroConta+" o seu saldo � de: R$ "+saldoAtual+" e est� negativo!");
			}
			
			sc.close();
	}
}
