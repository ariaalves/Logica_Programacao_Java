package faccat;
import java.util.Scanner;
public class Exercicio22IfElseSalarioFuncionario {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o n�mero de horas trabalhadas no m�s pelo funcion�rio:");
		int horaTrabalhada=sc.nextInt();
		System.out.println("Digite o valor da hora trabalhada");
		float valorHora=sc.nextFloat();
		float acrescimo=(valorHora*50)/100;
		float salarioTotal01=valorHora*horaTrabalhada;
		float salarioTotal02=salarioTotal01+acrescimo;
		
			if(horaTrabalhada>40) {
				System.out.println("O funcion�rio trabalhou "+horaTrabalhada+"h e seu sal�rio final vai ser: R$ "+salarioTotal02);
			}
			
			else {
				System.out.println("O funcion�rio trabalhou "+horaTrabalhada+"h e seu sal�rio final vai ser: R$ "+salarioTotal01);
			}
			
			sc.close();
	}
}
