package faccat;
import java.util.Scanner;

public class Exercicio40IfElseCalculoDesconto {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite a descri��o do produto: ");
        String descricao = sc.nextLine();
        
        System.out.print("Digite a quantidade adquirida: ");
        int quantidade = sc.nextInt();
        
        System.out.print("Digite o pre�o unit�rio: ");
        double precoUnitario = sc.nextDouble();
        
        double total = quantidade * precoUnitario;
        
        double desconto = 0;
        
	        if (quantidade <= 5) {
	            desconto = total * 0.02;
	        } 
	        
	        else if (quantidade <= 10) {
	            desconto = total * 0.03;
	        } 
	        
	        else {
	            desconto = total * 0.05;
	        }
        
        double totalAPagar = total - desconto;
        
        System.out.println("Descri��o do produto: " + descricao);
        System.out.println("Quantidade adquirida: " + quantidade);
        System.out.println("Pre�o unit�rio: " + precoUnitario);
        System.out.println("Total: " + String.format("%.2f", total));
        System.out.println("Desconto: " + String.format("%.2f", desconto));
        System.out.println("Total a pagar: " + String.format("%.2f", totalAPagar));
        
        sc.close();
	}
}
