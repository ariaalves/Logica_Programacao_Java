package faccat;
import java.util.Scanner;

public class Exerc�cio32IfElseVencedor {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o nome do primeiro time: ");
		String time01=sc.nextLine();
		System.out.println("Digite o nome do segundo time: ");
		String time02=sc.nextLine();
		System.out.println("Digite o n�mero de gols que "+time01+" marcou:");
		int golsTime01=sc.nextInt();
		System.out.println("Digite o n�mero de gols que "+time02+" marcou:");
		int golsTime02=sc.nextInt();
		
			if(golsTime01==golsTime02) {
				System.out.println("EMPATE");
			}
			
			else if(golsTime01>golsTime02) {
				System.out.println(time01+" venceu!");
			}
			
			else {
				System.out.println(time02+" venceu!");
			}
			
		sc.close();
	}
}
