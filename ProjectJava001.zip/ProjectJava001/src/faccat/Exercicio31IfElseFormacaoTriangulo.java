package faccat;
import java.util.Scanner;
	
public class Exercicio31IfElseFormacaoTriangulo {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o valor de A: ");
		int valorA=sc.nextInt();
		System.out.println("Digite o valor de B: ");
		int valorB=sc.nextInt();
		System.out.println("Digite o valor de C: ");
		int valorC=sc.nextInt();
		
		int soma01=valorB+valorC;
		int soma02=valorA+valorC;
		int soma03=valorA+valorB;
		
			if(soma01>valorA && soma02>valorB && soma03>valorC) {
				System.out.println("Um tri�ngulo foi formado!");
			}
			
			else {
				System.out.println("N�o foi formado um tri�ngulo!");
			}
		
		sc.close();
	}
}
