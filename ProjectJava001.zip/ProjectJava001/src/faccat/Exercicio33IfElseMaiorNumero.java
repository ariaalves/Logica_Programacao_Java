package faccat;
import java.util.Scanner;


public class Exercicio33IfElseMaiorNumero {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o primeiro n�mero: ");
		int numero01=sc.nextInt();
		System.out.println("Digite o segundo n�mero: ");
		int numero02=sc.nextInt();
		
			if(numero01==numero02) {
				System.out.println("N�meros iguais");
			}
			
			else if(numero01>numero02) {
				System.out.println("Primeiro maior");
			}
			
			else {
				System.out.println("Segundo maior");
			}
			
			sc.close();
	}
}
