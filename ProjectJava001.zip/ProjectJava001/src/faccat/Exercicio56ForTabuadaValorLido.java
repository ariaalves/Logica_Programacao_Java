package faccat;
import java.util.Scanner;
public class Exercicio56ForTabuadaValorLido {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		 System.out.print("Digite um valor entre 1 e 10: ");
	        int valor = sc.nextInt();

	        if (valor >= 1 && valor <= 10) {
	            for (int i = 1; i <= 10; i++) {
	                int resultado = valor * i;
	                System.out.println(valor + " x " + i + " = " + resultado);
	            }
	        } 
	        
	        else {
	            System.out.println("Valor inv�lido. Digite um valor entre 1 e 10.");
	        }
	        
	     sc.close();
	}
}
