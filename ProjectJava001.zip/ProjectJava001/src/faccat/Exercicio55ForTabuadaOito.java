package faccat;

public class Exercicio55ForTabuadaOito {
	public static void main(String[]args) {
		for (int i = 1; i <= 10; i++) {
            int resultado = i * 8;
            System.out.println("8 x " + i + " = " + resultado);
        }
	}
}
