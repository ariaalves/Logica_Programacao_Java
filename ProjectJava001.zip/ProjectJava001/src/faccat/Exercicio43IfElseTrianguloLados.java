package faccat;
import java.util.Scanner;

public class Exercicio43IfElseTrianguloLados {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("Digite o valor de a: ");
        double a = sc.nextDouble();

        System.out.print("Digite o valor de b: ");
        double b = sc.nextDouble();

        System.out.print("Digite o valor de c: ");
        double c = sc.nextDouble();

        if ((a < b + c) && (b < a + c) && (c < a + b)) {
            if (a == b && b == c) {
                System.out.println("Tri�ngulo Equil�tero");
            } 
            
            else if (a == b || b == c || a == c) {
                System.out.println("Tri�ngulo Is�sceles");
            } 
            
            else {
                System.out.println("Tri�ngulo Escaleno");
            }
            
        } 
        
        else {
            System.out.println("N�o � poss�vel formar um tri�ngulo");
        }
        
       sc.close();
	}
}
