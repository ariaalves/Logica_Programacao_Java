package faccat;
import java.util.Scanner;

public class Exercicio44DoWhileDivisaoValidacao {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		float valor1, valor2, resultado;

        do {
            System.out.print("Digite o primeiro valor: ");
            valor1 = sc.nextFloat();

            System.out.print("Digite o segundo valor: ");
            valor2 = sc.nextFloat();

	            if (valor2 == 0) {
	                System.out.println("VALOR INV�LIDO: O segundo valor n�o pode ser zero!");
	            }

        } while (valor2 == 0);

        resultado = valor1 / valor2;

        System.out.println("O resultado da divis�o �: " + resultado);
        
        sc.close();
	}
}
