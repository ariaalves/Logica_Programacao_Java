package faccat;
import java.util.Scanner;

public class Exercicio45WhileDivisaoValidacao {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite o primeiro valor: ");
        int valor1 = sc.nextInt();

        System.out.print("Digite o segundo valor (n�o pode ser zero): ");
        int valor2 = sc.nextInt();

        while (valor2 == 0) {
            System.out.print("Valor inv�lido. Digite um valor diferente de zero: ");
            valor2 = sc.nextInt();
        }

        double resultado = (double) valor1 / valor2;

        System.out.println("O resultado da divis�o �: " + resultado);
        
      sc.close();
	}
}
