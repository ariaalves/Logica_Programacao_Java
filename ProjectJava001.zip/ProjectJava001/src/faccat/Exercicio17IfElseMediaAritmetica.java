package faccat;
import java.util.Scanner;
public class Exercicio17IfElseMediaAritmetica {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o nome do aluno: ");
		String nome=sc.nextLine();
		System.out.println("Digite a primeira nota do aluno: ");
		float nota01=sc.nextFloat();
		System.out.println("Digite a segunda nota do aluno: ");
		float nota02=sc.nextFloat();
		float mediaAritmetica=(nota01+nota02)/2;
		 	if(mediaAritmetica>=6) {
		 		System.out.println(nome+ " foi aprovado(a)!");
		 	}
		 	
		 	else {
		 		System.out.println(nome+ " foi reprovado(a)!");
		 	}
		 	
		 sc.close();
	}
}
