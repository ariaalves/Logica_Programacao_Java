package faccat;
import java.util.Scanner;

public class Exercicio35IfElseGastoCombustivel {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite a quantidade de litros vendidos:");
		float litros=sc.nextFloat();
		System.out.println("Informe o tipo de combust�vel (A-�lccol,G-gasolina): ");
		String tipoCombustivel=sc.next();
		float valorLitro=0;
		float valorTotal=0;
		
		if (tipoCombustivel.equalsIgnoreCase("A")) {
            if (litros <= 20) {
                valorLitro = 2.9f * 0.97f;
            } 
            
            else {
                valorLitro = 2.9f * 0.95f;
            }
            
        } 
		
		else if (tipoCombustivel.equalsIgnoreCase("G")) {
            if (litros <= 20) {
                valorLitro = 2.9f * 0.96f;
            } 
            
            else {
                valorLitro = 2.9f * 0.94f;
            }
        }
			 
		valorTotal=litros*valorLitro;	
		
		System.out.println("O valor a ser pago ser� de: R$ " + valorTotal);
		
		sc.close();
	}
}
