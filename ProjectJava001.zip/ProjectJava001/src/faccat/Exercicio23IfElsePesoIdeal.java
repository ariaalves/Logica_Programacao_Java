package faccat;
import java.util.Scanner;

public class Exercicio23IfElsePesoIdeal {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o seu nome:");
		String nome=sc.nextLine();
		System.out.println("O seu sexo � feminino ou masculino: ");
		String sexo=sc.nextLine();
		System.out.println("Digite a sua altura: ");
		float altura=sc.nextFloat();
		String sexoFeminino="f";
		String sexoMasculino="m";
		float pesoFeminino=(62.1f*altura)-44.7f;
		float pesoMasculino=(72.7f*altura)-68;
		
		if (sexo.equals(sexoFeminino)) {
		    System.out.println(nome + " o seu peso ideal �: " + pesoFeminino);
		} 
		
		else if (sexo.equals(sexoMasculino)) {
		    System.out.println(nome + " o seu peso ideal �: " + pesoMasculino);
		} 
		
		else {
		    System.out.println("Informe seu sexo novamente");
		}

			
	sc.close();
	}
}
