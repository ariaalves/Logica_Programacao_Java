package faccat;
import java.util.Scanner;
public class Exercicio16IfElseCustoMacas {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o n�mero de ma��s compradas: ");
		int numeroMacas=sc.nextInt();
		float custoMenosDuzia=numeroMacas*1.3f;
		float custoDuzia=numeroMacas*1;
			if(numeroMacas<12) {
				System.out.println("O custo total �: R$ "+custoMenosDuzia);
			}
			
			else {
				System.out.println("O custo total �: R$ "+custoDuzia);
			}
			
		sc.close();
	}
}
