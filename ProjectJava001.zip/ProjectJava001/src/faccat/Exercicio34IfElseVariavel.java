package faccat;
import java.util.Scanner;

public class Exercicio34IfElseVariavel {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o valor de x: ");
		int x=sc.nextInt();
		System.out.println("Digite o valor de y: ");
		int y=sc.nextInt();
		int z=(x*y)+5;
		String resposta;
		
			if(z<=0) {
				resposta="A";
			}
			
			else if(z<=100) {
				resposta="B";
			}
			
			else {
				resposta="C";
			}
			
		System.out.println("Z: "+z+" Resposta: "+resposta);
		
		sc.close();
	}
}
