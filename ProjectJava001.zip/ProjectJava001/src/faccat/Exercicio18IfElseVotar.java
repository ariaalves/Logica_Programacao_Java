package faccat;
import java.util.Scanner;

public class Exercicio18IfElseVotar {
	public static void main(String[]args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Digite o ano atual em que voc� se encontra: ");
	int anoAtual=sc.nextInt();
	System.out.println("Digite o ano em que voc� nasceu: ");
	int anoNascimento=sc.nextInt();
	int idadeVoto= anoAtual-anoNascimento;
		if(idadeVoto>=16) {
			System.out.println("Voc� j� pode votar no Brasil!");
		}
		
		else {
			System.out.println("Voc� n�o pode votar no Brasil!");
		}
		
	sc.close();
	}
}
