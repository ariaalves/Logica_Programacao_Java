package faccat;
import java.util.Scanner;

public class Exercicio62ForMediaAritmeticaNotas {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite o n�mero de alunos na turma: ");
        int numAlunos = sc.nextInt();
        double somaNotas = 0;
	
	        for (int i = 1; i <= numAlunos; i++) {
	            System.out.print("Digite a nota do aluno " + i + ": ");
	            double nota = sc.nextDouble();
	            somaNotas += nota;
	        }

        double media = somaNotas / numAlunos;

        System.out.println("A m�dia aritm�tica das notas �: " + String.format("%.2f", media));
        
      sc.close();
	}
}
