package manzano;
import java.util.Scanner;

public class Exercicio7GDistributiva {
	public static void main(String[]args) {
		Scanner sc= new Scanner(System.in);

        System.out.println("Digite o valor de A:");
        int a = sc.nextInt();

        System.out.println("Digite o valor de B:");
        int b = sc.nextInt();

        System.out.println("Digite o valor de C:");
        int c = sc.nextInt();

        System.out.println("Digite o valor de D:");
        int d = sc.nextInt();

        int resultado;

        //Resultado de A com B
        resultado = a * (b + c + d);
        System.out.println("A * (B + C + D) = " + resultado);

        //Resultado de A com C
        resultado = a * (c + d);
        System.out.println("A * (C + D) = " + resultado);

        //Resultado de A com D
        resultado = a * d;
        System.out.println("A * D = " + resultado);

        //Resultado de B com C
        resultado = b * (c + d);
        System.out.println("B * (C + D) = " + resultado);

        //Resultado B com D
        resultado = b * d;
        System.out.println("B * D = " + resultado);

        //Resultado C com D
        resultado = c * d;
        System.out.println("C * D = " + resultado);

        sc.close();
	}
}
