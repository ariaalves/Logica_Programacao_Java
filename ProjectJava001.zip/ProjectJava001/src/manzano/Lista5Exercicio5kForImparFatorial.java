package manzano;

public class Lista5Exercicio5kForImparFatorial {
	public static void main(String[]args) {
		int fatorial = 1;
        int contFatorial = 0;
        int resto = 0;

	        for (int i = 1; i < 11; i++) {
	            resto = i % 2;
		            if (resto == 1) {
		                contFatorial = i;
		
			                while (contFatorial > 1) {
			                    fatorial = fatorial * contFatorial;
			                    contFatorial--;
			                }
		
		                System.out.println(fatorial);
		
		                fatorial = 1;
		            }
	        }
	} 
}
