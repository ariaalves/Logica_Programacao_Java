package manzano;
import java.util.Scanner;

public class Lista3Exercicio5kWhileComodosCasa {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		double area = 0;
        double areaTotal = 0;
        String resposta = "S";


	        while (!resposta.equals("N")) {
	            System.out.print("Digite o nome do c�modo: ");
	            String nome = sc.nextLine();
	
	            System.out.print("Digite a largura do c�modo: ");
	            double largura = sc.nextDouble();
	
	            System.out.print("Digite o comprimento do c�modo: ");
	            double comprimento = sc.nextDouble();
	            sc.nextLine(); 
	
	            area = largura * comprimento;
	            areaTotal += area;
	
	            System.out.println("A �rea do " + nome + " � de " + area + " m�.");
	
	            System.out.print("Deseja adicionar mais um c�modo (S/N)? ");
	            resposta = sc.nextLine();
	        }

        System.out.println("A �rea total da resid�ncia � de: " + areaTotal + " m�.");

       sc.close();
	}
}
