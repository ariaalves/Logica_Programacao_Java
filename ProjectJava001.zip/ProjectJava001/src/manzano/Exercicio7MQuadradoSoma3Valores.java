package manzano;
import java.util.Scanner;

public class Exercicio7MQuadradoSoma3Valores {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite o valor de A: ");
        int a = sc.nextInt();

        System.out.print("Digite o valor de B: ");
        int b = sc.nextInt();

        System.out.print("Digite o valor de C: ");
        int c = sc.nextInt();

        int soma = a + b + c;
        int quadradoSoma = soma * soma;

        System.out.println("O quadrado da soma dos tr�s valores lidos �: " + quadradoSoma);
        
        sc.close();
	}
}
