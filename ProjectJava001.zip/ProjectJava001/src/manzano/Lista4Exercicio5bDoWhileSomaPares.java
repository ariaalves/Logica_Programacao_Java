package manzano;

public class Lista4Exercicio5bDoWhileSomaPares {
	public static void main(String[]args) {
		 int contadora = 1;
	     int resto = 0;
	     int soma = 0;

	        do {
	            resto = contadora % 2;
		            if (resto == 0) {
		                soma = soma + contadora;
		            }
	            contadora++;
	        } while (contadora < 501);
	        
	        System.out.println("A soma dos n�meros pares entre 1 e 500 �: " + soma);
	}
}
