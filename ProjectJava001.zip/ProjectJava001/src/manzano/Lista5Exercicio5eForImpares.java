package manzano;

public class Lista5Exercicio5eForImpares {
	public static void main(String[]args) {
		for (int i = 0; i < 21; i++) {
            int resto = i % 2;
            
	            if (resto == 1) {
	                System.out.println(i);
	            }
	}
  }
}
