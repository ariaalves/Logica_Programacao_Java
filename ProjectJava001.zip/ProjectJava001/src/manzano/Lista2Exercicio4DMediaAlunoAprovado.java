package manzano;
import java.util.Scanner;

public class Lista2Exercicio4DMediaAlunoAprovado {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Digite a primeira nota: ");
        double nota1 = sc.nextDouble();
        
        System.out.println("Digite a segunda nota: ");
        double nota2 = sc.nextDouble();
        
        System.out.println("Digite a terceira nota: ");
        double nota3 = sc.nextDouble();
        
        System.out.println("Digite a quarta nota: ");
        double nota4 = sc.nextDouble();
        
        double media = (nota1 + nota2 + nota3 + nota4) / 4.0;
        
	        if (media >= 7.0) {
	            System.out.println("Aluno aprovado!");
	            System.out.println("M�dia: " + media);
	        } 
	        
	        else {
	            System.out.println("Digite a nota do exame: ");
	            double notaExame = sc.nextDouble();
	            
	            double novaMedia = (media + notaExame) / 2.0;
	            
		            if (novaMedia >= 5.0) {
		                System.out.println("Aluno aprovado no exame!");
		                System.out.println("Nova m�dia: " + novaMedia);
		            } 
		            
		            else {
		                System.out.println("Aluno reprovado!");
		                System.out.println("M�dia: " + novaMedia);
		            }
	        }
        
	      sc.close();
	}
}
