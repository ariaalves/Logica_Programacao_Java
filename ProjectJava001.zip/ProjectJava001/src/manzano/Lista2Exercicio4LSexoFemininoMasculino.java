package manzano;
import java.util.Scanner;

public class Lista2Exercicio4LSexoFemininoMasculino {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite o nome da pessoa: ");
        String nome = sc.nextLine();

        System.out.print("Digite o sexo da pessoa (M/F): ");
        String sexo = sc.nextLine();

	        if (sexo.equalsIgnoreCase("M")) {
	            System.out.println("Ilmo Sr. " + nome);
	        } 
	        
	        else if (sexo.equalsIgnoreCase("F")) {
	            System.out.println("Ilma Sra. " + nome);
	        } 
	        
	        else {
	            System.out.println("Digite o sexo novamente");
	        }
	        
	     sc.close();
	}
}
