package manzano;
import java.util.Scanner;

public class Exercicio7FTrocaValores {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("Digite o valor para a vari�vel A: ");
        int a = sc.nextInt();

        System.out.print("Digite o valor para a vari�vel B: ");
        int b = sc.nextInt();

        System.out.println("Valores originais:");
        System.out.println("A = " + a);
        System.out.println("B = " + b);

        
        int temporaria = a;
        a = b;
        b = temporaria;

        System.out.println("Valores trocados:");
        System.out.println("A = " + a);
        System.out.println("B = " + b);
        
       sc.close();
	}
}
