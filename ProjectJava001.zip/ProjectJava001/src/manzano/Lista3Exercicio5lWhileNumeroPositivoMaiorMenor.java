package manzano;
import java.util.Scanner;

public class Lista3Exercicio5lWhileNumeroPositivoMaiorMenor {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		 System.out.print("Digite um n�mero positivo (ou um negativo para sair): ");
		    int numero = sc.nextInt();
		    int maior = numero;
		    int menor = numero;

			    while (numero >= 0) {
			        System.out.print("Digite um n�mero positivo (ou um negativo para sair): ");
			        numero = sc.nextInt();
				        if (numero > maior) {
				            maior = numero;
				        }
				        
				        if (numero < menor && numero > 0) {
				            menor = numero;
				        }
			    }

		    System.out.println("O maior n�mero �: " + maior);
		    System.out.println("O menor n�mero �: " + menor);
		    
		 sc.close();
	}
}
