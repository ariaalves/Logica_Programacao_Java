package manzano;

public class Lista5Exercicio5gForTresPotencia {
	public static void main(String[]args) {
		int resultado = 1;

	        System.out.println("1");

		        for (int i = 1; i < 16; i++) {
		            resultado = resultado * 3;
		            System.out.println(resultado);
		        }
	}
}
