package manzano;
import java.util.Scanner;
public class Exercicio7AConversaoCelsiusFahrenheit {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite a temperatura em Celsius: ");
		int celsius=sc.nextInt();
		int fahrenheit=((9*celsius)+160)/5;
		
		System.out.println("A temperatura em fahrenheit �: "+fahrenheit+"F");
		
		sc.close();
	}
	
	
}
