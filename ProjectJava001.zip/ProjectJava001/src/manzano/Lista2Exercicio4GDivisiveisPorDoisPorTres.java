package manzano;
import java.util.Scanner;

public class Lista2Exercicio4GDivisiveisPorDoisPorTres {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		int[] numeros = new int[4];
        System.out.println("Digite quatro n�meros:");

	        for (int i = 0; i < 4; i++) {
	            numeros[i] = sc.nextInt();
	        }

	        System.out.println("N�meros divis�veis por 2 e 3:");

	        for (int i = 0; i < 4; i++) {
		            if (numeros[i] % 2 == 0 && numeros[i] % 3 == 0) {
		                System.out.println(numeros[i]);
		            }
	        }
	        
	    sc.close();
	}
}
