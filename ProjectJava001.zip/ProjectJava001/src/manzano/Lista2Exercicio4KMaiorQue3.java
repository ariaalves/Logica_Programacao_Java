package manzano;
import java.util.Scanner;

public class Lista2Exercicio4KMaiorQue3 {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("Digite um valor: ");
        int valor = sc.nextInt();

	        if (valor <= 3) {
	            System.out.println("O valor �: " + valor);
	        }
	        
	    sc.close();
	}
}
