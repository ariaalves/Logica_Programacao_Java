package manzano;
import java.util.Scanner;
public class Exercicio7IQuadradoDiferenca {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite o valor de A: ");
        int a = sc.nextInt();

        System.out.print("Digite o valor de B: ");
        int b = sc.nextInt();

        int diferenca = a - b;
        int resultado = diferenca * diferenca;

        System.out.println("O quadrado da diferen�a entre A e B �: " + resultado);
        
        sc.close();

	}
}
