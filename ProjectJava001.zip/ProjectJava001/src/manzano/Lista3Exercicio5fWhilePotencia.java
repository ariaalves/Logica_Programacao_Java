package manzano;
import java.util.Scanner;

public class Lista3Exercicio5fWhilePotencia {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite o n�mero da base: ");
        int base = sc.nextInt();

        System.out.print("Digite o n�mero do expoente: ");
        int expoente = sc.nextInt();

        int resultado = 1;
        int contadora = 1;

	        while (contadora <= expoente) {
	            resultado *= base;
	            contadora++;
	        }

        System.out.println("A pot�ncia de " + base + " elevado a " + expoente + " � igual a: " + resultado);

        sc.close();
	}
}
