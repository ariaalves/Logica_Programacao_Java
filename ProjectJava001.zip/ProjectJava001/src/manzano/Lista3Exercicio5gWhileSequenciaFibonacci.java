package manzano;

public class Lista3Exercicio5gWhileSequenciaFibonacci {
	public static void main(String[]args) {
		
        int numero = 15;
        
        int atual = 1;
        int antecessor = 0;
        int soma;
        int contadora = 1;

        System.out.println(atual);
        
	        while (contadora < numero) {
	            soma = atual + antecessor;
	            System.out.println(soma);
	            antecessor = atual;
	            atual = soma;
	            contadora++;
	        }
        
    }
}

