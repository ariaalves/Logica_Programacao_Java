package manzano;
import java.util.Scanner;

public class Lista4Exercicio5fDoWhileSomaMedia {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		
        int numero = 0;
        int soma = 0;
        double mediaAritmetica = 0;
        int totalNum = 0;
        int contadora = 0;

	        do {
	            System.out.print("Digite um n�mero positivo (ou negativo para sair): ");
	            numero = sc.nextInt();
		            if (numero > 0) {
		                soma += numero;
		                totalNum++;
		            }
	            mediaAritmetica = (double) soma / totalNum;
	            contadora++;
	        } while (contadora <= numero);

        System.out.println("A soma dos n�meros �: " + soma);
        System.out.println("O total de n�meros inseridos �: " + totalNum);
        System.out.println("A m�dia aritm�tica �: " + mediaAritmetica);
        
      sc.close();
	}
}
