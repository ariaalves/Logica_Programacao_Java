package manzano;

public class Lista4Exercicio5cDoWhileDivisivelQuatro {
	public static void main(String[]args) {
		 int contadora = 1;
	     int resto = 0;
	     
	        do {
	            resto = contadora % 4;
		            if (resto == 0) {
		                System.out.println(contadora);
		            }
	            contadora++;
	        } while (contadora < 200);
	}
}
