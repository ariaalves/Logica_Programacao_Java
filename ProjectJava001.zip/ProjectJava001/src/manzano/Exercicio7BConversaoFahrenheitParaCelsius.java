package manzano;
import java.util.Scanner;

public class Exercicio7BConversaoFahrenheitParaCelsius {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite a temperatura em graus Fahrenheit: ");
		float fahrenheit=sc.nextFloat();
		float celsius=(fahrenheit-32)/1.8f;
		System.out.println("A temperatura em celsius �: "+celsius+"�");
		
		sc.close();
	}
}
