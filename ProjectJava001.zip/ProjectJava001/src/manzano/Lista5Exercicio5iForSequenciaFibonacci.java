package manzano;

public class Lista5Exercicio5iForSequenciaFibonacci {
	public static void main(String[]args) {
		int atual = 1;
        int antecessor = 0;
        int soma = 0;

	        for (int i = 1; i < 15; i++) {
	            soma = atual + antecessor;
	            System.out.println(soma);
	            antecessor = atual;
	            atual = soma;
	        }
	}
}
