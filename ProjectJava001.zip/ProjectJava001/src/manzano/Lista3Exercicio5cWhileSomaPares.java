package manzano;

public class Lista3Exercicio5cWhileSomaPares {
	public static void main(String[]args) {
		 int soma = 0;
	        int contadora = 1;
	        int resto = 0;

		        while (contadora < 501) {
		            resto = contadora % 2;
			            if (resto == 0) {
			                soma += contadora;
			            }
			            
			            contadora++;
		        }

	        System.out.println("A soma dos n�meros pares entre 1 e 500 �: " + soma);
	}
}
