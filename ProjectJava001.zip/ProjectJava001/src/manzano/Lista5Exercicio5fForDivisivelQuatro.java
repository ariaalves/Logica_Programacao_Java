package manzano;

public class Lista5Exercicio5fForDivisivelQuatro {
	public static void main(String[]args) {
		int resto;

	        for (int i = 1; i < 200; i++) {
	            resto = i % 4;
	
		            if (resto == 0) {
		                System.out.println(i);
		            }
	        }
	}
}
