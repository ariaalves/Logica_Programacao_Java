package manzano;
import java.util.Scanner;

public class Lista2Exercicio4HMaiorMenorValor {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		int maior = Integer.MIN_VALUE;
        int menor = Integer.MAX_VALUE;

	        for (int i = 0; i < 5; i++) {
	            System.out.print("Digite um n�mero: ");
	            int numero = sc.nextInt();
	
		            if (numero > maior) {
		                maior = numero;
		            }
		
		            if (numero < menor) {
		                menor = numero;
		            }
	        }
	
	        System.out.println("O maior n�mero �: " + maior);
	        System.out.println("O menor n�mero �: " + menor);
	        
	    sc.close();
	}
}
