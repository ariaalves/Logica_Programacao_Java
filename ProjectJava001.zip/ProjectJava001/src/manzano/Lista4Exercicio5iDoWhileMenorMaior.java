package manzano;
import java.util.Scanner;

public class Lista4Exercicio5iDoWhileMenorMaior {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite um n�mero positivo (ou um valor negativo para sair): ");
		int numero = sc.nextInt();
        
	        if (numero > 0) {
	            int maior = numero;
	            int menor = numero;
	            
		            do {
		                System.out.print("Digite um n�mero positivo (ou um valor negativo para sair): ");
		                numero = sc.nextInt();
		                
		                if (numero > maior) {
		                    maior = numero;
		                }
		                if (numero < menor && numero > 0) {
		                    menor = numero;
		                }
		            } while (numero > 0);
	            
	            System.out.println("O maior n�mero �: " + maior);
	            System.out.println("O menor n�mero �: " + menor);
	            
	        } 
	        
	        else {
	            System.out.println("Voc� precisa inserir um n�mero positivo para saber qual � o maior e o menor.");
	        }
	        
	     sc.close();
	        
    
	}
}
