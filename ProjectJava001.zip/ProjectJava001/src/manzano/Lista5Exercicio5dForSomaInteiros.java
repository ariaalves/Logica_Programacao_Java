package manzano;

public class Lista5Exercicio5dForSomaInteiros {
	public static void main(String[]args) {
		int soma = 0;
        
	        for (int i = 1; i < 501; i++) {
	            soma = soma + i;
	        }
        
        System.out.println(soma);
	}
}
