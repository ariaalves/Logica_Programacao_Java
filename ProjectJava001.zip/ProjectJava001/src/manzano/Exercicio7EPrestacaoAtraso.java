package manzano;
import java.util.Scanner;

public class Exercicio7EPrestacaoAtraso {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o valor da presta��o: ");
		float valorPrestacao=sc.nextFloat();
		System.out.println("Digite a taxa mensal de atraso: ");
		float taxaAtraso=sc.nextFloat();
		System.out.println("Digite o tempo em meses de atraso: ");
		int tempoAtraso=sc.nextInt();
		float prestacaoAtraso=valorPrestacao+(valorPrestacao*taxaAtraso/100)*tempoAtraso;
		
		System.out.println("A presta��o com atraso ficou em: "+prestacaoAtraso);
		
		sc.close();
	}
}
