package manzano;

public class Lista4Exercicio5aDoWhileQuadradoNumeroInteiro {
	public static void main(String[]args) {
		int contadora = 15;
        int potencia = 0;
        
	        do {
	            potencia = contadora * contadora;
	            System.out.println(potencia);
	            contadora++;
	        } while (contadora < 201);
	}
}
