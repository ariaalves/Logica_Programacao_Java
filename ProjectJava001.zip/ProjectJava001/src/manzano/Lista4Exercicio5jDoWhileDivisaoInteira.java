package manzano;
import java.util.Scanner;

public class Lista4Exercicio5jDoWhileDivisaoInteira {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);

	        System.out.print("Digite o dividendo: ");
	        int dividendo = sc.nextInt();

	        System.out.print("Digite o divisor: ");
	        int divisor = sc.nextInt();

	        int quociente = 0;
	        	
		        do {
		            dividendo-=divisor;
		            quociente++;
		        } while (dividendo >= divisor);

	        System.out.println("O resultado inteiro da divis�o �: " + quociente);
	        
	     sc.close();
	}
}
