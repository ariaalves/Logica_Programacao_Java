package manzano;
import java.util.Scanner;

public class Exercicio7CCalculoVolumeCircuferencia {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Digite o valor do raio da lata de �leo(divida o di�metro por 2): ");
		float raio=sc.nextFloat();
		System.out.println("Digite a altura da lata de �leo: ");
		float altura=sc.nextFloat();
		float volumeCircuferencia=3.14f*(raio*raio)*altura;
		
		System.out.println(volumeCircuferencia);
		sc.close();
	}
	}

