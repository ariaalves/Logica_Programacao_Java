package manzano;

public class Lista3Exercicio5dWhileNumeroImpar {
	public static void main(String[]args) {
		int contadora = 0;
        int resto = 0;

	        while (contadora < 21) {
	            resto = contadora % 2;
	            
		            if (resto == 1) {
		                System.out.println(contadora + " Sou um n�mero �mpar");
		            }
		            
	            contadora++;
	        }
	}
}
