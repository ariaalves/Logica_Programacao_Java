package manzano;
import java.util.Scanner;

public class Lista2Exercicio4BModuloNumero {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite um n�mero inteiro: ");
        int numero = sc.nextInt();

        int modulo = Math.abs(numero);

        System.out.println("O valor absoluto do n�mero �: " + modulo);
        
        sc.close();
	}
}
