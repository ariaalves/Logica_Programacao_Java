package manzano;

public class Lista3Exercicio5hWhileCelsiusFahrenheit {
	public static void main(String[]args) {
		 	int celsius = 10;
	        int contadora = 1;
	        int soma = 0;
	        int fahrenheit = 0;

		        while (contadora < 11) {
		            soma = soma + celsius;
		            fahrenheit = ((9 * soma) + 160) / 5;
		            System.out.println(fahrenheit + " F");
		            contadora++;
		        }
	}
}
