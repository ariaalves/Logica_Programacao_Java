package manzano;
import java.util.Scanner;

public class Lista5Exercicio5bForTabuada {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		
		 	System.out.print("Insira o n�mero que deseja saber a tabuada: ");
	        int numero = sc.nextInt();
	        
		        for (int i = 1; i < 11; i++) {
		            int resultado = numero * i;
		            System.out.println(numero + " x " + i + " = " + resultado);
		        }
		        
		    sc.close();
	}
}
