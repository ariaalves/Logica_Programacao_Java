package manzano;
import java.util.Scanner;

public class Lista3Exercicio5iWhileSomaMediaAritmetica {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		int valor = 0;
        int contadora = 1;
        double media = 0;


	        while (contadora < 11) {
	            System.out.print("Digite um n�mero: ");
	            int numero = sc.nextInt();
	            valor = valor + numero;
	            contadora++;
	        }

        media = valor / 10.0;

        System.out.println("A soma dos 10 valores � " + valor + " e a m�dia aritm�tica � " + media + ".");
        
        sc.close();
	}
}
