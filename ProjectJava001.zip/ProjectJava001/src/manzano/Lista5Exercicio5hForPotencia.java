package manzano;
import java.util.Scanner;

public class Lista5Exercicio5hForPotencia {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite o n�mero da base: ");
        int base = sc.nextInt();
        System.out.print("Digite o n�mero do expoente: ");
        int expoente = sc.nextInt();
        int resultado = 1;

	        for (int i = 1; i <= expoente; i++) {
		            if (expoente != 0) {
		                resultado *= base;
		            } 
		            
		            else {
		                System.out.println("1");
		            }
	        }

        System.out.println(resultado);
		
		
		
		sc.close();
	}
}
