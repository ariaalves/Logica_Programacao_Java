package manzano;
import java.util.Scanner;

public class Exercicio7JConversaoRealDolar {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite a cota��o do d�lar: ");
        double cotacao = sc.nextDouble();

        System.out.print("Digite a quantidade de d�lares dispon�vel: ");
        double quantidadeDolares = sc.nextDouble();

        double valorReais = cotacao * quantidadeDolares;

        System.out.println("O valor em reais �: R$" + valorReais);

        sc.close();
	}
}
