package manzano;

public class Lista5Exercicio5cForSomaInteiro {
	public static void main(String[]args) {
		int soma = 0;

	        for (int i = 1; i <= 100; i++) {
	            soma = soma + i;
	        }

        System.out.println("A soma dos n�meros inteiros �: "+soma);
	}
}
