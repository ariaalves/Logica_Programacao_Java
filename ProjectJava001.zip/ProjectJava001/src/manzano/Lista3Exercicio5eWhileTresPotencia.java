package manzano;

public class Lista3Exercicio5eWhileTresPotencia {
	public static void main(String[]args){
		int contadora = 1;
        int resultado = 1;

        System.out.println("1");

	        while (contadora < 16) {
	            resultado = resultado * 3;
	            System.out.println(resultado);
	            contadora++;
	        }
	}
}
