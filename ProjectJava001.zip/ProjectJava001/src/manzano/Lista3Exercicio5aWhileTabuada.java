package manzano;
import java.util.Scanner;

public class Lista3Exercicio5aWhileTabuada {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite um n�mero: ");
        int numero = sc.nextInt();
        
        int contadora = 1;
        int multiplicacao;
        
	        while (contadora < 11) {
	            multiplicacao = numero * contadora;
	            System.out.println(numero + " x " + contadora + " = " + multiplicacao);
	            contadora++;
	        }
	        
	    sc.close();
	}
}
