package manzano;

public class Lista4Exercicio5gDoWhileImparFatorial {
	public static void main(String[]args) {
		int contadora = 1;
        int fatorial = 1;
        int contFatorial = 0;
        int resto = 0;

	        do {
	            resto = contadora % 2;
		            if (resto == 1) {
		                contFatorial = contadora;
			                while (contFatorial > 1) {
			                    fatorial = fatorial * contFatorial;
			                    contFatorial--;
		                }
	                System.out.println(fatorial);
	                fatorial = 1;
	            }
	            contadora++;
	        } while (contadora < 11);
	}
}
