package manzano;
import java.util.Scanner;

public class Lista4Exercicio5hDoWhileAreaComodo {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		String resposta;
	    String nome;
	    int largura=0;
	    int comprimento=0;
	    int areaIndividual = 0;
	    int areaTotal = 0;

		    do {
		        System.out.print("Digite o nome do c�modo: ");
		        nome = sc.next();
	
		        System.out.print("Digite a largura do c�modo: ");
		        largura = sc.nextInt();
	
		        System.out.print("Digite o comprimento do c�modo: ");
		        comprimento = sc.nextInt();
	
		        areaIndividual = largura * comprimento;
		        System.out.println(nome + " tem uma �rea de " + areaIndividual + " m�");
	
		        areaTotal += areaIndividual;
	
		        System.out.print("Deseja continuar [S/N]? ");
		        resposta = sc.next();
		        
		    } while (!resposta.equalsIgnoreCase("N"));

	    System.out.println("A �rea total �: " + areaTotal + " m�");
	    
	    sc.close();
	}
}
