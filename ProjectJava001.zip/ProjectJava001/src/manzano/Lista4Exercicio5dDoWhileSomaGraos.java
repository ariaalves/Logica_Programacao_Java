package manzano;
import java.math.BigInteger;

public class Lista4Exercicio5dDoWhileSomaGraos {
	public static void main(String[]args) {
		BigInteger  graos = BigInteger.ONE;
		BigInteger  soma = graos;
        int contadora = 1;
        
	        do {
	            graos = graos.multiply(BigInteger.TWO);;
	            soma = soma.add(graos);
	            contadora++;
	        } while (contadora < 64);
	        
        System.out.println("A soma dos gr�os �: " + soma);
	}
}
