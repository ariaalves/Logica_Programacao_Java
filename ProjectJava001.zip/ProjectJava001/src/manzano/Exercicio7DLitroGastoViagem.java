package manzano;
import java.util.Scanner;

public class Exercicio7DLitroGastoViagem {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o tempo gasto na viagem (em horas): ");
        double tempo = sc.nextDouble();

        System.out.print("Digite a velocidade m�dia durante a viagem (em km/h): ");
        double velocidade = sc.nextDouble();

        double distancia = tempo * velocidade;
        double litrosUsados = distancia / 12;

        System.out.println("Velocidade m�dia: " + velocidade + " km/h");
        System.out.println("Tempo gasto na viagem: " + tempo + " horas");
        System.out.println("Dist�ncia percorrida: " + distancia + " km");
        System.out.println("Quantidade de litros usada na viagem: " + litrosUsados + " litros");
        
        sc.close();
    }
}
