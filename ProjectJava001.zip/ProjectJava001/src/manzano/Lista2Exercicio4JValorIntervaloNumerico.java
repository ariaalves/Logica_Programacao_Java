package manzano;
import java.util.Scanner;

public class Lista2Exercicio4JValorIntervaloNumerico {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Digite um valor entre 1 e 9: ");
        int valor = sc.nextInt();
        
	        if (valor >= 1 && valor <= 9) {
	            System.out.println("O valor est� na faixa.");
	        } 
	        
	        else {
	            System.out.println("O valor est� fora da faixa.");
	        }
	        
	    sc.close();
	        
	}
}
