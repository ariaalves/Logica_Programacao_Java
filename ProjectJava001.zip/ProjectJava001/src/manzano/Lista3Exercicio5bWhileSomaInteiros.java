package manzano;

public class Lista3Exercicio5bWhileSomaInteiros {
	public static void main(String[]args) {
		int soma = 0;
        int contadora = 1;

	        while (contadora < 101) {
	            soma = soma + contadora;
	            contadora++;
	        }

        System.out.println("A soma dos n�meros inteiros de 1 at� 100 �: " + soma);
	}
}
