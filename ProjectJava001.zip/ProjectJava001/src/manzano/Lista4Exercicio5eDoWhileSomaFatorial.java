package manzano;
import java.util.Scanner;

public class Lista4Exercicio5eDoWhileSomaFatorial {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		
		int numero;
        int contadora = 1;
        int somaFat = 0;
        int fatorial = 1;
        int contFatorial = 0;

	        do {
	            System.out.print("Digite um n�mero: ");
	            numero = sc.nextInt();
	            contFatorial = numero;
	
		            while (contFatorial > 1) {
		                fatorial = fatorial * contFatorial;
		                contFatorial--;
		            }
		
	            somaFat = somaFat + fatorial;
	            contadora++;
	            fatorial = 1;
	        } while (contadora < 16);

        System.out.println("A soma fatorial dos n�meros �: " + somaFat);
        
        sc.close();
	}
}
