package manzano;

public class Lista5Exercicio5jForCelsiusFahremheit {
	public static void main(String[]args) {
		int soma = 0;
        int fahrenheit = 0;
        int celsius = 10;

	        for (int i = 1; i < 11; i++) {
	            soma = soma + celsius;
	            fahrenheit = ((9 * soma) + 160) / 5;
	            System.out.println(fahrenheit + " F");
	        }
	}
}
